This is my To-Do List Web Application project.
I created this project using HTML, CSS, and JavaScript to manage daily tasks more easily.
The main idea of the project is to let users add, edit, delete, and mark tasks as complete.
It also allows setting a deadline for each task.
If a task is not completed before its deadline, it automatically becomes “Timed Out” and changes color to show it’s late.

In this project, I used HTML for creating the structure of the webpage.
The HTML file contains the input field where users can type their tasks, a date and time input for the deadline,
and buttons to add, edit, delete, and mark tasks as complete.

I used CSS to design and style the page.
The website has a modern, colorful, and responsive design.
It looks good on both desktop and mobile screens.
The interface includes a dark blue gradient background, rounded task cards, and colorful buttons —
green for completing tasks, blue for editing, and red for deleting.

For the functionality, I used JavaScript (ES6).
JavaScript is responsible for adding new tasks to the list, editing existing ones, deleting tasks,
and marking them as complete or timed out.
It also keeps checking the current time to mark tasks as “Timed Out” when their deadline passes.
All the data works locally in the browser, so the project runs without needing any internet connection or external server.

This project helped me understand how to use:

DOM manipulation to dynamically update the webpage

Event handling for buttons and user actions

JavaScript arrays and objects for storing and updating task data

CSS styling for making a clean and modern user interface

To run this project, I just open it in VS Code and use the Live Server extension.
That allows me to view the website in my browser and interact with it easily.

The project was created by Syed Zain Ul Abidin as part of my web development work
to demonstrate my understanding of frontend development, including HTML, CSS, and JavaScript.