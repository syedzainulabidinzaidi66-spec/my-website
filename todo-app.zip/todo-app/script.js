const taskInput = document.getElementById("taskInput");
const deadlineInput = document.getElementById("deadlineInput");
const addTaskBtn = document.getElementById("addTaskBtn");
const taskList = document.getElementById("taskList");

let tasks = [];

function renderTasks() {
  taskList.innerHTML = "";
  const now = new Date();

  tasks.forEach((task) => {
    const li = document.createElement("li");
    li.classList.add("task");
    if (task.completed) li.classList.add("completed");

    const deadlinePassed = task.deadline && new Date(task.deadline) < now;
    if (!task.completed && deadlinePassed) {
      li.classList.add("timed-out");
    }

    const span = document.createElement("span");
    span.textContent = task.title;

    const btnDiv = document.createElement("div");
    btnDiv.classList.add("buttons");

    const completeBtn = document.createElement("button");
    completeBtn.textContent = "✓";
    completeBtn.classList.add("complete-btn");
    completeBtn.onclick = () => toggleComplete(task.id);

    const editBtn = document.createElement("button");
    editBtn.textContent = "✎";
    editBtn.classList.add("edit-btn");
    editBtn.onclick = () => editTask(task.id);

    const deleteBtn = document.createElement("button");
    deleteBtn.textContent = "🗑";
    deleteBtn.classList.add("delete-btn");
    deleteBtn.onclick = () => deleteTask(task.id);

    btnDiv.append(completeBtn, editBtn, deleteBtn);
    li.append(span, btnDiv);
    taskList.appendChild(li);
  });
}

function addTask() {
  const title = taskInput.value.trim();
  const deadline = deadlineInput.value;

  if (!title) return alert("Please enter a task!");

  const newTask = {
    id: Date.now(),
    title,
    deadline,
    completed: false,
  };

  tasks.push(newTask);
  taskInput.value = "";
  deadlineInput.value = "";
  renderTasks();
}

function toggleComplete(id) {
  tasks = tasks.map((task) =>
    task.id === id ? { ...task, completed: !task.completed } : task
  );
  renderTasks();
}

function editTask(id) {
  const newTitle = prompt("Edit your task:");
  if (newTitle) {
    tasks = tasks.map((task) =>
      task.id === id ? { ...task, title: newTitle } : task
    );
    renderTasks();
  }
}

function deleteTask(id) {
  tasks = tasks.filter((task) => task.id !== id);
  renderTasks();
}

addTaskBtn.addEventListener("click", addTask);
